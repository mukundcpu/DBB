# Python Merge Sample
This is a sample to demonstrate how to use the Z Open Automation Utilities Python API to merge two datasets. It assumes that you have installed the Python API package and have environment variables properly configured.

Usage: `python3 merge.py`
