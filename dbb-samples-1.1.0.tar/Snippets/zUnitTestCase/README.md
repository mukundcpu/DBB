# zUnit Test Case (JCLExec Sample)
JCLExec is introduced in DBB v1.0.2 API that allows user to submit a JCL job and get the job status.  This sample shows how to use JCLExec to submit a ZUnit test case from a JCL and outputs the test case results in console.

The sample is comprised of a single Groovy file:
* RunZUnitJCL.groovy